import React from 'react';
import data from './data.json';
import {BrowserRouter, Route} from "react-router-dom";
import LoginForm from './LoginForm';

class productPage extends React.Component {

	render() {
		var singleProduct = data.filter(xData => xData.productId === this.props.match.params.id);

		return(
			<div className="SingleProduct padT50">
                <h2 className="title">{singleProduct[0].productTitle}</h2>
                <div className="row clearfix">
	                <div className="col-md-6 col-xs-12">
	                    <img src={require(`./images/${singleProduct[0].productImage}`)} className="img-responsive img-shadow" alt="" />
	                    <div className="prod-det bord-bot">
	                    <h3 className="prod-title">{singleProduct[0].productTitle}</h3>
	                    <h3 className="prod-price">{singleProduct[0].productPrice}</h3>
	                    </div>
	                </div>
	                <div className="col-md-6 col-xs-12">
	                	<h3 className="bord-bot">{singleProduct[0].productBrand}</h3>
	                	<p>{singleProduct[0].productDescription}</p>
	                </div>
                </div>
                <LoginForm />
            </div>
		)
	}
}

export default productPage