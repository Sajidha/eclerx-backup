import React from 'react';
import Banner from './Banner';
import ProductList from './ProductList';
import LoginForm from './LoginForm';

class Home extends React.Component {
	constructor() {
		super();
		this.state = {name: "Will"};
	}

	render() {
		setTimeout(() => {
			this.setState({name: "Bob"})
		}, 2000)

		const title = "Title";
		return(
			<div className="clearfix padT50">
				<Banner name={this.state.name} />
				<ProductList title={title} />
				<LoginForm />
			</div>
		)
	}
}

export default Home