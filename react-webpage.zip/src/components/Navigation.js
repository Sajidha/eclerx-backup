import React from 'react';
import { Link , NavLink } from 'react-router-dom';

class Navigation extends React.Component {

	render() {
		return(
			<div>				
				<nav class="navbar navbar-default navbar-fixed-top">
				  <div class="container-fluid">
				    <div class="navbar-header">
					    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
					        <span class="icon-bar"></span>
					        <span class="icon-bar"></span>
					        <span class="icon-bar"></span>                        
				      	</button>
					    <Link to="/" class="navbar-brand">WebSiteName</Link>
				    </div>
				    <div class="collapse navbar-collapse" id="myNavbar">
					    <ul class="nav navbar-nav">
					    	<li><NavLink to="/home" activeClassName="active">Home</NavLink></li>
					      	<li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Page 1 <span class="caret"></span></a>
						        <ul class="dropdown-menu">
						          <li><a href="#">Page 1-1</a></li>
						          <li><a href="#">Page 1-2</a></li>
						          <li><a href="#">Page 1-3</a></li>
						        </ul>
					      	</li>
						    <li><Link to="/about">About</Link></li>
						    <li><Link to="/services">Services</Link></li>
							<li><Link to="/contact">Contact</Link></li>
					    </ul>
					    <ul class="nav navbar-nav navbar-right">
					      <li><a href="#"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
					      <li data-toggle="modal" data-target="#myModal"><a href="#"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
					    </ul>
				    </div>
				  </div>
				</nav>

			</div>
		)
	}
}

export default Navigation