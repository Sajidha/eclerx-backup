import React from 'react';
import LoginForm from './LoginForm';

import Collapsible from 'react-collapsible';

class About extends React.Component {

	render() {
		return(
			<div className="clearfix padT50">
				<h2>About</h2>
				
		        <Collapsible trigger="Start here">
			        
			        <Collapsible trigger="Inner tab 1">
				        <p>This is the collapsible content. It can be any element or React component you like.</p>
				        <p>It can even be another Collapsible component. Check out the next section!</p>
				    </Collapsible>

				    <Collapsible trigger="Inner tab 2">
				        <p>This is the collapsible content. It can be any element or React component you like.</p>
				        <p>It can even be another Collapsible component. Check out the next section!</p>
				    </Collapsible>

				    <Collapsible trigger="Inner tab 3">
				        <p>This is the collapsible content. It can be any element or React component you like.</p>
				        <p>It can even be another Collapsible component. Check out the next section!</p>
				    </Collapsible>

			      </Collapsible>
				<LoginForm />
			</div>
		)
	}
}

export default About