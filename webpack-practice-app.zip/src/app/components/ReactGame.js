import React from 'react';

class ReactGame extends React.Component {
   render() {
      return (
         <div>
            <h2>React Game Component</h2>
         </div>
      );
   }
}

export default ReactGame;