import React from 'react';

class ReactCalci extends React.Component {
   render() {
      return (
         <div>
            <h2>React Calci Component</h2>
         </div>
      );
   }
}

export default ReactCalci;