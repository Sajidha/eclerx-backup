import React from 'react';

class ReactRandom extends React.Component {
   render() {
      return (
         <div>
            <h2>React Random Component</h2>
         </div>
      );
   }
}

export default ReactRandom;