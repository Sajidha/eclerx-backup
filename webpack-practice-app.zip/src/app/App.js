import React from 'react';
import { Link , NavLink } from 'react-router-dom';
import ReactMap from './components/ReactMap';
import ReactCalci from './components/ReactCalci';
import ReactGame from './components/ReactGame';
import ReactRandom from './components/ReactRandom';

class App extends React.Component {
   render() {
      return (
         <div className="main-app">
            <div className="col-md-6 app-item">
               <div className="flip-container item-rt" ontouchstart="this.classList.toggle('hover');">
                  <Link to="/react-map">
                  <div className="flipper">
                  	<div className="front card">
                     <img src="./app/icon1.png" className="img-responsive img-circle" alt="" />
                     </div>
                     <div className="back card">
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </p>
                     </div>
                  </div>
                  </Link>
               </div>
            </div>
            <div className="col-md-6 app-item">
            	<div className="flip-container item-lt" ontouchstart="this.classList.toggle('hover');">
                  <Link to="/react-calci">
                  <div className="flipper">
                     <div className="front card">
                     <img src="./app/icon2.png" className="img-responsive img-circle" alt="" />
                     </div>
                     <div className="back card">
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </p>
                     </div>
                  </div>
                  </Link>
               </div>
            </div>
            <div className="col-md-6 app-item">
            	<div className="flip-container item-rt" ontouchstart="this.classList.toggle('hover');">
                  <Link to="/react-game">
                  <div className="flipper">
                     <div className="front card">
                     <img src="./app/icon3.png" className="img-responsive img-circle" alt="" />
                     </div>
                     <div className="back card">
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </p>
                     </div>
                  </div>
                  </Link>
               </div>
            </div>
            <div className="col-md-6 app-item">
            	<div className="flip-container item-lt" ontouchstart="this.classList.toggle('hover');">
                  <Link to="/react-random">
                  <div className="flipper">
                     <div className="front card">
                     <img src="./app/icon4.png" className="img-responsive img-circle" alt="" />
                     </div>
                     <div className="back card">
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </p>
                     </div>
                  </div>
                  </Link>
               </div>
            </div>
         </div>
      );
   }
}

export default App;