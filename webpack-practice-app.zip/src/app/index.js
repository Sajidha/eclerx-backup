import React from 'react';
import ReactDOM from 'react-dom';
import {BrowserRouter, Route, Redirect} from "react-router-dom";
import styles from './index.css';
import App from './App';
import ReactMap from './components/ReactMap';
import ReactCalci from './components/ReactCalci';
import ReactGame from './components/ReactGame';
import ReactRandom from './components/ReactRandom';

ReactDOM.render(
	<BrowserRouter>
		<div>
		    <Route exact path='/' component={App} />
		    <Route exact path='/react-map' component={ReactMap} />
		    <Route exact path='/react-calci' component={ReactCalci} />
		    <Route exact path='/react-game' component={ReactGame} />
		    <Route exact path='/react-random' component={ReactRandom} />
	    </div>
    </BrowserRouter>, 
    document.getElementById('app'));